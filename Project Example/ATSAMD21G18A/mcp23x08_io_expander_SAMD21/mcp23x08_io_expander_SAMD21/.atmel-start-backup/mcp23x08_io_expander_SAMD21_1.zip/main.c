#include <atmel_start.h>
#include "mcp23x08_driver/mcp23x08_driver_basic.h"

mcp23x08_info_t mcp23x08Info;

void print(char *const pBuffer, size_t u8Length);
uint8_t i2c_read(uint8_t addr, uint8_t reg, uint8_t *buf, uint16_t len);
uint8_t i2c_write(uint8_t addr, uint8_t reg, uint8_t *buf, uint16_t len);

int main(void)
{
	/* Initializes MCU, drivers and middle-ware */
	atmel_start_init();
	
	mcp23x08_basic_initialize(MCP23008_VARIANT, MCP23X08_PROTOCOL_I2C, MCP23X08_IIC_ADDRESS_A110, MCP23X08_SPI_ADDRESS_A00);
	mcp23x08_info(&mcp23x08Info);

	mcp23x08_interface_debug_print("Chip name :\t%s\n\r", mcp23x08Info.chip_name1);
	mcp23x08_interface_debug_print("Manufacturer: \t%s\n\r", mcp23x08Info.manufacturer_name);

	mcp23x08_interface_debug_print("Interface: \t%s\n\r", mcp23x08Info.interface1);
	mcp23x08_interface_debug_print("Supply voltage max : \t%0.2fV\n\r", mcp23x08Info.supply_voltage_max_v);
	mcp23x08_interface_debug_print("Supply voltage min: \t%0.2fV\n\r", mcp23x08Info.supply_voltage_min_v);
	mcp23x08_interface_debug_print("Maximum current: \t%0.1fmA\n\r", mcp23x08Info.max_current_ma);
	mcp23x08_interface_debug_print("Temperature Max: \t%.1fC\n\r", mcp23x08Info.temperature_max);
	mcp23x08_interface_debug_print("Temperature Min: \t%.1fC\n\r", mcp23x08Info.temperature_min);
	mcp23x08_interface_debug_print("Driver version: \tV%.1f.%.2d\n\r", (mcp23x08Info.driver_version / 1000), (uint8_t)(mcp23x08Info.driver_version - (uint8_t)(mcp23x08Info.driver_version / 100)*100));

	mcp23x08_basic_gpio_set_direction(MCP23X08_GPIO_PIN_7, MCP23X08_OUTPUT);
	uint8_t add;
	mcp23x08_basic_get_addr_pin((uint8_t*)&add);
	mcp23x08_interface_debug_print("addr %.2p\n", add);

	/* Replace with your application code */
	while (1) {
		mcp23x08_basic_gpio_to       (MCP23X08_GPIO_PIN_7, MCP23X08_GPIO_HIGH);
		mcp23x08_interface_delay_ms(500);	
	}
}

void print(char *const pBuffer, size_t u8Length)
{
	struct io_descriptor *io;
	usart_sync_get_io_descriptor(&USART_0, &io);
	usart_sync_enable(&USART_0);

	io_write(io, (char *)pBuffer, u8Length);
	
}

uint8_t i2c_read(uint8_t addr, uint8_t reg, uint8_t *buf, uint16_t len)
{
	
	struct io_descriptor *I2C_0_io;

	i2c_m_sync_get_io_descriptor(&I2C_0, &I2C_0_io);
	i2c_m_sync_enable(&I2C_0);
	i2c_m_sync_set_slaveaddr(&I2C_0, addr, I2C_M_SEVEN);
	io_write(I2C_0_io, (uint8_t *)&reg, 1);
	
	//i2c_m_sync_set_slaveaddr(&I2C_0, addr, I2C_M_SEVEN);
	io_read(I2C_0_io, buf,  len);
	return 0;
}

uint8_t i2c_write(uint8_t addr, uint8_t reg, uint8_t *buf, uint16_t len)
{
	uint8_t tempBuffer[len+1];
	tempBuffer[0] = reg;
		
	for(int index = 1; index < len + 1; index++){
		tempBuffer[index] = buf[index - 1];
	}
	struct io_descriptor *I2C_0_io;

	i2c_m_sync_get_io_descriptor(&I2C_0, &I2C_0_io);
	i2c_m_sync_enable(&I2C_0);
	i2c_m_sync_set_slaveaddr(&I2C_0, addr, I2C_M_SEVEN);
	io_write(I2C_0_io, (uint8_t *)tempBuffer, len + 1);
	return 0;
}
